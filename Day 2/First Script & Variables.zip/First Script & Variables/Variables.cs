using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Variables : MonoBehaviour
{

    public int score = 5;

    float position = 2.5f;

    char C = 'A';

    public string playerName = "Raja";

    public float destroyTiming;

    // Start is called before the first frame update
    void Start()
    {
        print(score);

        print(playerName);


        Destroy(gameObject, destroyTiming);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
