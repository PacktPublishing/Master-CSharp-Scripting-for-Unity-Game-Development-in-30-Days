using UnityEngine;


public class SecondScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //Destroy(gameObject);
        print("Start");

    }

    // Update is called once per frame
    void Update()
    {
        print("Update");
    }
}
