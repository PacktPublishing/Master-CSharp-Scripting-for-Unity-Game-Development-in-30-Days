﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTest : MonoBehaviour
{

    public float moveSpeed;

    float xInput, yInput;

    Vector2 targetPos;
    Rigidbody2D rb;
    SpriteRenderer sp;

    public float jumpForce;
    bool isGrounded;


    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        sp = GetComponent<SpriteRenderer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //mousePos.z = 10f;

        //transform.position = mousePos;

        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            //mousePos.z = 10f;

            targetPos = mousePos;
            
        }

        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            //Jump();
            //isGrounded = false;
        }
    }

    private void FixedUpdate()
    {
        xInput = Input.GetAxis("Horizontal");
        yInput = Input.GetAxis("Vertical");

        //transform.Translate(xInput * moveSpeed, yInput * moveSpeed, 0f);

        //MoveToClickPoint();

        PlatformerMovement();
        FlipDirection();
    }

    void MoveToClickPoint()
    {
        transform.position = Vector2.MoveTowards(transform.position, targetPos, moveSpeed);
    }

    void PlatformerMovement()
    {
        rb.velocity = new Vector2(xInput * moveSpeed, rb.velocity.y);
    }

    void FlipDirection()
    {
        if(rb.velocity.x > 0.1f)
        {
            sp.flipX = false;
        }
        else if(rb.velocity.x < -0.1f)
        {
            sp.flipX = true;
        }
    }

    void Jump()
    {
        rb.velocity = Vector2.up * jumpForce;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
        }
    }
}
