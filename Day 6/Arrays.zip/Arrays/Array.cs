using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Array : MonoBehaviour
{
    int s1 = 55;
    int s2 = 60;
    int s3 = 52;

    string n1 = "Raja";
    string n2 = "Suman";
    string n3 = "Rio";

    int[] marks = {55, 60 ,52, 64};
    //0   1   2    3
    //array index starts with 0


    public string[] names;


    // points  5  , print 2nd , 4th
    public int[] points;


    // Start is called before the first frame update
    void Start()
    {
        //print(marks.Length);

        marks[0] = 45;
        marks[3] = 68;

        print(marks[0]);
        print(marks[3]);

        print(names[0]);
        print(names[2]);


        print(points[1]);
        print(points[3]);



    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
