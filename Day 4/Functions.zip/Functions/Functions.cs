using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Functions : MonoBehaviour
{
    public bool gameOver = false;
    public int number;

    // Start is called before the first frame update
    void Start()
    {
        //GameOver();

        int result = SquareCalculator(number);
        print(result);
    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver)
        {

            GameOver();

        }
        
    }

    void GameOver()
    {
        print("GameOver");
        //show the GameOver Menu

        Destroy(gameObject);


    }


    int SquareCalculator(int num)
    {
        num = num * num; //5 * 5

        return num;
    }






}
