using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Condition : MonoBehaviour
{
    public int score;


    // Start is called before the first frame update
    void Start()
    {
        if( score > 10 )
        {
            print("You Win");
        }
        else
        {
            print("Keep Playing");
        }


        if(transform.position.x > 5f)
        {
            Destroy(gameObject);
        }
        else
        {
            print("You are Safe");
        }

        //if Y position is greater than 10 then destroy

        if (transform.position.y > 10f)
        {
            Destroy(gameObject);
        }
        else
        {
            print("You Are Safe");
        }


    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
