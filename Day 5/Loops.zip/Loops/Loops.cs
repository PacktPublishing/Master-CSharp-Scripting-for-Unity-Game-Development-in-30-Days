using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loops : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        /*
        print(0);
        print(1);
        print(2);
        print(3);
        print(4);
        print(5);
        print(6);
        print(7);
        print(8);
        print(9);
        print(10);
        */

        // initialize Counter     i = 0
        // Checking Condition     0 < 10
        // incrementing counter   1
        // the loop runs until the condition is true

        for (int i = 0; i < 10; i++)
        {
            //print(i);
        }

        //print your name 5 Times
        for( int i = 1; i < 6; i++)
        {
            print("Raja");
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
