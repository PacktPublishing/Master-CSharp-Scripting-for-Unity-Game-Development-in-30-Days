using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boolean : MonoBehaviour
{


    public bool gameOver = false;

    // !gameOver

    // Start is called before the first frame update
    void Start()
    {
        if(gameOver == true)
        {
            print("GameOver");
            Destroy(gameObject);
        }

        if(gameOver)
        {
            //!gameOver is same as gameOver == false
            //gameOver is same as gameOver == true

            //do someting
        }


    }

    // Update is called once per frame
    void Update()
    {
        if (gameOver == true)
        {
            print("GameOver");
            Destroy(gameObject);
        }
    }
}
