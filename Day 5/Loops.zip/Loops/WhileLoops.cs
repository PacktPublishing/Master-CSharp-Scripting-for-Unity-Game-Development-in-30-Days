using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhileLoops : MonoBehaviour
{

    public bool gameOver = false;

    // Start is called before the first frame update
    void Start()
    {
        for(int i = 1; i <= 5 ; i++) // i < 6 or i <= 5 are same
        {
            print("Raja");
        }

        int j = 1;
        while (j <= 5)
        {
            print("Raja2");

            j++;
        }

        /*
        while (true)
        {
            //infinite loop
            print("I'm Stuck");
            if(gameOver == true)
            {
                break;// return 
            }
        }
        */


    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
