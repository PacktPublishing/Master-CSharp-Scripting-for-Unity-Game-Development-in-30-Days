using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Advertisements;



public class AdsManager : MonoBehaviour, IUnityAdsInitializationListener, IUnityAdsLoadListener, IUnityAdsShowListener
{
    public static AdsManager instance;

    string gameID = "5299576";

    string interstitialAdId = "Interstitial_Android";
    string bannerAdID = "Banner_Android";




    private void Awake()
    {
        instance = this;

        InitializeAds();
    }

    void InitializeAds()
    {
        Advertisement.Initialize(gameID, false, this);
    }

    public void ShowAds()
    {
        Advertisement.Load(interstitialAdId, this);

        Advertisement.Show(interstitialAdId, this);
    }

    //GameOver
    //AdsManager.instance.ShowAds();


    public void ShowBannerAd()
    {

        Advertisement.Banner.SetPosition(BannerPosition.BOTTOM_CENTER);

        Advertisement.Banner.Load(bannerAdID);

        Advertisement.Banner.Show(bannerAdID);

    }

    //Start
    //AdsManagaer.instance.ShowBannerAd();



    public void OnInitializationComplete()
    {
        Debug.Log("Initialized");
    }

    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        throw new System.NotImplementedException();
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        Debug.Log("Ads Loaded");
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        throw new System.NotImplementedException();
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Debug.Log("Ads Clicked");
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        Debug.Log("Ads Complete");
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Debug.Log("Ads Failed");
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Debug.Log("Ads Start");
    }

}
