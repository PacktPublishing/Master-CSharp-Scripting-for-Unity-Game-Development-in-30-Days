using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MutlipleConditions : MonoBehaviour
{

    public int power = 0;


    // Start is called before the first frame update
    void Start()
    {
    
  
        if(power > 2 && power < 5){

            print("Super Power");

        }
        else if(power > 5 && power < 10)
        {
            print("Ultra Power");
        }

        if(power < 2 || power > 10)
        {
            print("Normal Power");
        }




        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
